<?php
    $db_id = 'root';
    $db_pw = "";
    $db_name = "exam_db";
?>