<table border=1 width=100% style="background: rgba(37, 52, 100, 0.8); text-align: center; color: white; bottom: 0px;">
  <tr><td height=70>2023 BSSM</td></tr>
</table>