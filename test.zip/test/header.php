<table border=1 width=100% style="background: rgba(37, 52, 100, 0.8); text-align: center; font-weight: 900; color: white;">
  <tr><td height=150 style="font-size: 70px;">PHP 수행평가 2407박현준</td></tr>
  <tr><td height=50 style="background: lightblue;">
    <a href=view.php style="text-decoration: none; color: black; margin-right: 30px;">view.php</a>
   </td></tr>
</table>